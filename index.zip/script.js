document.getElementById('get-weather').addEventListener('click', function() {
    const city = document.getElementById('city-input').value.trim();
    const apiKey = 'bc11c25026c7aacfcb0e75ab91384ba7'; 
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=${apiKey}&units=metric`;

    console.log('Fetching data from:', url); 
    fetch(url)
        .then(response => {
            if (!response.ok) {
                                console.error('Response error:', response);
                throw new Error('City not found');
            }
            return response.json();
        })
        .then(data => {
            console.log('Data fetched:', data);
            const resultDiv = document.getElementById('result');
            const temperature = data.main.temp;
            const weatherDescription = data.weather[0].description;
            const humidity = data.main.humidity;
            const windSpeed = data.wind.speed;

            // Display results
            resultDiv.innerHTML = `
                <h2>Weather in ${data.name}</h2>
                <p>Temperature: ${temperature}°C</p>
                <p>Condition: ${weatherDescription}</p>
                <p>Humidity: ${humidity}%</p>
                <p>Wind Speed: ${windSpeed} m/s</p>
            `;
            resultDiv.style.display = 'block'; // Show the result
        })
        .catch(error => {
            console.error('Catch error:', error); // Log the full error for debugging
            const resultDiv = document.getElementById('result');
            resultDiv.innerHTML = `<p style="color: red;">Error: ${error.message}</p>`;
            resultDiv.style.display = 'block'; // Show the result
        });
});
